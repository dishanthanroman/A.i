# AI Auto Shorts (Android starter)

A small Java Android app project configured for GitHub Actions APK builds. It lets a user select a video and attempts to copy its first 30 seconds into an MP4 file using Android's `MediaExtractor` and `MediaMuxer` APIs.

## Build an APK on GitHub
1. Upload/extract the *contents* of this ZIP into the repository root (do not upload this ZIP as the only project file).
2. Confirm `settings.gradle`, root `build.gradle`, `gradle.properties`, `app/`, and `.github/workflows/android.yml` are visible in the repository root.
3. Open **Actions** and run **Android APK Build**, or push a commit.
4. When the workflow succeeds, open that run and download the `AI-Auto-Shorts-debug-apk` artifact. Extract the artifact ZIP to get `app-debug.apk`.

## Important scope note
This is a buildable starter/basic trimmer, not a complete AI highlight detector. It does not yet detect interesting moments, automatically crop to vertical 9:16, generate captions, or download YouTube/Drive videos. Those features need additional implementation and, for AI highlight selection, usually a server/API. Use videos you own or are authorized to edit.

## Compatibility
Minimum Android API is 26 (Android 8.0); Android 8.1 is API 27. GitHub Actions builds the APK in the cloud; Android Studio is not required on your phone.
