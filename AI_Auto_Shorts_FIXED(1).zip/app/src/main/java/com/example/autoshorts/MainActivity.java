package com.example.autoshorts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private Uri selectedUri;
    private TextView status;
    private Button makeButton;
    private ProgressBar progress;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(20));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF7F4FF);

        TextView title = new TextView(this);
        title.setText("AI Auto Shorts");
        title.setTextSize(28);
        title.setTextColor(0xFF241A35);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("Choose a video and create a short preview. This starter version trims the first 30 seconds; AI highlight detection and automatic vertical reframing require a separate AI processing service.");
        intro.setTextSize(16);
        intro.setTextColor(0xFF494454);
        intro.setPadding(0, dp(18), 0, dp(22));
        root.addView(intro, matchWrap());

        Button pick = new Button(this);
        pick.setText("1. Choose video");
        root.addView(pick, matchWrap());
        pick.setOnClickListener(v -> chooseVideo());

        makeButton = new Button(this);
        makeButton.setText("2. Create 30-second clip");
        makeButton.setEnabled(false);
        LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = dp(12);
        root.addView(makeButton, bp);
        makeButton.setOnClickListener(v -> trimVideo());

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(48), dp(48)); pp.topMargin = dp(20);
        root.addView(progress, pp);

        status = new TextView(this);
        status.setText("Ready. Select a video from your phone.");
        status.setTextSize(14);
        status.setTextColor(0xFF494454);
        status.setPadding(0, dp(18), 0, 0);
        root.addView(status, matchWrap());

        TextView foot = new TextView(this);
        foot.setText("Output is saved in this app's Movies folder. No video is uploaded.");
        foot.setTextSize(12); foot.setTextColor(0xFF6B6575); foot.setPadding(0, dp(18), 0, 0);
        root.addView(foot, matchWrap());
        setContentView(root);
    }

    private void chooseVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        startActivityForResult(i, PICK_VIDEO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedUri = data.getData();
            if (selectedUri != null) {
                getContentResolver().takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                status.setText("Video selected: " + displayName(selectedUri));
                makeButton.setEnabled(true);
            }
        }
    }

    private void trimVideo() {
        if (selectedUri == null) return;
        makeButton.setEnabled(false); progress.setVisibility(View.VISIBLE);
        status.setText("Processing video… Keep the app open.");
        new Thread(() -> {
            String result;
            try {
                File outDir = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "AI_Auto_Shorts");
                if (!outDir.exists() && !outDir.mkdirs()) throw new Exception("Could not create output folder");
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                File out = new File(outDir, "short_" + stamp + ".mp4");
                copyAndTrim(selectedUri, out);
                result = "Clip created successfully:\n" + out.getAbsolutePath();
            } catch (Exception e) {
                result = "Could not create clip: " + e.getMessage() + "\nTry a standard MP4 video.";
            }
            final String message = result;
            new Handler(Looper.getMainLooper()).post(() -> {
                progress.setVisibility(View.GONE); status.setText(message); makeButton.setEnabled(true);
                Toast.makeText(this, message.startsWith("Clip created") ? "Clip created" : "Clip failed", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void copyAndTrim(Uri uri, File output) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(this, uri, null);
        MediaMuxer muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int[] map = new int[extractor.getTrackCount()];
        boolean any = false; long durationUs = 30_000_000L;
        for (int i=0; i<extractor.getTrackCount(); i++) {
            MediaFormat f = extractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/"))) {
                map[i] = muxer.addTrack(f); any = true;
                if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_DURATION)) durationUs = Math.min(durationUs, f.getLong(MediaFormat.KEY_DURATION));
            } else map[i] = -1;
        }
        if (!any) throw new Exception("No supported audio/video tracks found");
        muxer.start();
        ByteBuffer buffer = ByteBuffer.allocate(2 * 1024 * 1024);
        android.media.MediaCodec.BufferInfo info = new android.media.MediaCodec.BufferInfo();
        for (int i=0; i<extractor.getTrackCount(); i++) if (map[i] >= 0) extractor.selectTrack(i);
        extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
        while (true) {
            int track = extractor.getSampleTrackIndex();
            if (track < 0) break;
            long time = extractor.getSampleTime();
            if (time < 0 || time > durationUs) break;
            if (map[track] >= 0) {
                buffer.clear(); int size = extractor.readSampleData(buffer, 0);
                if (size < 0) break;
                info.offset = 0; info.size = size; info.presentationTimeUs = time;
                info.flags = (extractor.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                muxer.writeSampleData(map[track], buffer, info);
            }
            if (!extractor.advance()) break;
        }
        try { muxer.stop(); } finally { muxer.release(); extractor.release(); }
        if (output.length() == 0) { output.delete(); throw new Exception("The selected video format could not be trimmed"); }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) return c.getString(i); }
        } catch (Exception ignored) { }
        return "selected video";
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
}
